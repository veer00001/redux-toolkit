import { createSlice } from "@reduxjs/toolkit";


const cartSlice = createSlice({
    name: 'cart',
    initialState: [],
    reducers: {
        add(state, action) {
            let find = state.findIndex((item) => item.id === action.payload.id);
            if (find >= 0) {
                state[find].quantity += 1;
            } else {
                state.push(action.payload)
            }
        },
        remove(state, action) {
            return state.filter(item => item.id !== action.payload)
        },

        getcartTotal: (state) => {

            let total = 0;
            state.forEach((item) => {

                if (item.price === 'undefined') {
                    console.log('not')
                }
                else {
                    total += item.price
                }

            })
            // console.log(total)
        },


        invtreaseItemQuantity: (state, action) => {
            state = state.map((item) =>{
                if (item.id == action.payload) {
                    return { ...item, quantity: item.quantity += 1 }
                }
                return item;
            });
        },
        decreaseItemQuantity: (state, action) => {
            state = state.map((item) => {
                if (item.id == action.payload) {
                    return { ...item, quantity: item.quantity -= 1 }
                }
                return item;
            });
        },
    }
});

export const { add, remove, invtreaseItemQuantity, decreaseItemQuantity, getcartTotal } = cartSlice.actions
export default cartSlice.reducer;
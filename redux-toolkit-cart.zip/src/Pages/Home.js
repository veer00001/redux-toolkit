import React from 'react'
import Products from '../Component/Products';
const Home = () => {
    return (
        <div>

            <section>
 
                <Products />
            </section>
        </div>
    )
};
export default Home; 
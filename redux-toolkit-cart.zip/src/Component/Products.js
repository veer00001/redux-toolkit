import React, { useEffect, useState } from 'react'
import { useDispatch } from 'react-redux';
import { add } from '../store/cardSlice';
import { dataStore } from '../../src/datStore'


const Products = () => {
    let dispatch = useDispatch()
    // console.log(dataStore)
    const [Products, setProducts] = useState([]);

    // console.log(Products)

    useEffect(() => {
        const fetchProducts = async () => {

            // const res = await fetch('https://fakestoreapi.com/products');
            // const data = await res.json();
            //

            let data = dataStore
            setProducts(data)
        }
        fetchProducts()
    }, []);

    const addValue = (product) => {
        dispatch(add(product))
    }

    return (
        <div className='productsWrapper'>
            {
                Products.map(data => (
                    <div className='card' key={data.id}>
                        <img src={data.img} alt='' />
                        <h5>{data.price}</h5>
                        <button className='btn' onClick={() => addValue(data)} > ADD TO CART </button>
                    </div >

                ))
            }
        </div >
    )
}
export default Products

import React from 'react'
const Cart = () => {

    return (
        <div>
            <h3>Cart</h3>
            <div className='cartWrapper'>
                <div className='cartCard'>
                    <img src='' alt='' />
                    <h5> </h5>
                    <h5> </h5>
                    <button className='btn' >Remove</button>
                </div>
            </div>
        </div>
    )
}
export default Cart
